const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Order = require("../models/Order");
const auth = require("../middleware/auth");
const isAdmin = require("../middleware/isAdmin");

// 1) Get all users
router.get("/users", auth, isAdmin, async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

// 2) Block/Unblock user
router.patch("/users/:id/block", auth, isAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ msg: "User not found" });
    user.isActive = req.body.isActive !== false; // toggle
    await user.save();
    res.json({ msg: "User updated", user: { id: user._id, isActive: user.isActive } });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

// 3) Get all orders
router.get("/orders", auth, isAdmin, async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("userId", "name email")
      .populate("items.bookId", "title author");
    res.json(orders);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

// 4) Update order status
router.put("/orders/:id/status", auth, isAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ msg: "Order not found" });

    order.status = status;
    await order.save();
    res.json({ msg: "Order status updated", order });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
