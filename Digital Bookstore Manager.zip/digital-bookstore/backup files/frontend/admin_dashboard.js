const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user"));
document.getElementById("adminName").textContent = user?.name || "Admin";

function showTab(name) {
  document.querySelectorAll(".tab-section").forEach(s => s.style.display = "none");
  document.getElementById(name).style.display = "block";
  document.querySelectorAll(".tabs button").forEach(b => b.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
}

// BOOKS
async function fetchBooks() {
  const res = await fetch("http://localhost:5000/api/books", {
    headers: { Authorization: "Bearer " + token }
  });
  const books = await res.json();
  const list = document.getElementById("bookList");

  list.innerHTML = books.map(b => `
  <div class="book-card">
    <div class="book-card-header">${b.title}</div>
    <div class="book-card-body">
      <p><b>Author:</b> ${b.author}</p>
      <p><b>Price:</b> ₹${b.price}</p>
      <p><b>Stock:</b> ${b.stock}</p>
      <button onclick="editBook('${b._id}')">✏️ Edit</button>
      <button onclick="deleteBook('${b._id}')">🗑️ Delete</button>
    </div>
  </div>
`).join("");
}
function openBookModal(editMode = false, book = null) {
  document.getElementById("bookModal").style.display = "flex";
  document.getElementById("modalTitle").textContent = editMode ? "Edit Book" : "Add Book";

  const form = document.getElementById("bookForm");
  if (editMode && book) {
    form.dataset.editId = book._id;
    document.getElementById("title").value = book.title;
    document.getElementById("author").value = book.author;
    document.getElementById("price").value = book.price;
    document.getElementById("category").value = book.category || "";
    document.getElementById("description").value = book.description || "";
    document.getElementById("stock").value = book.stock || 0;
  } else {
    form.reset();
    delete form.dataset.editId;
  }
}

function closeBookModal() {
  document.getElementById("bookModal").style.display = "none";
}

document.getElementById("bookForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = e.target.dataset.editId;
  const body = {
    title: document.getElementById("title").value,
    author: document.getElementById("author").value,
    price: Number(document.getElementById("price").value),
    category: document.getElementById("category").value,
    description: document.getElementById("description").value,
    stock: Number(document.getElementById("stock").value)
  };
  const url = id ? `http://localhost:5000/api/books/${id}` : "http://localhost:5000/api/books";
  const method = id ? "PUT" : "POST";

  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify(body)
  });

  if (res.ok) {
    alert(id ? "Book updated" : "Book added");
    closeBookModal();
    fetchBooks();
  } else {
    alert("Failed to save book");
  }
});

async function editBook(id) {
  const res = await fetch(`http://localhost:5000/api/books/${id}`, {
    headers: { Authorization: "Bearer " + token }
  });
  const b = await res.json();
  openBookModal(true, b);
}

async function deleteBook(id) {
  if (!confirm("Delete this book?")) return;
  const res = await fetch(`http://localhost:5000/api/books/${id}`, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token }
  });
  if (res.ok) fetchBooks();
}

// USERS
async function fetchUsers() {
  const res = await fetch("http://localhost:5000/api/admin/users", {
    headers: { Authorization: "Bearer " + token }
  });
  const users = await res.json();
  const list = document.getElementById("userList");
  list.innerHTML = users.map(u => `
    <li>
      ${u.name} — ${u.email} — Role: ${u.role} — Active: ${u.isActive !== false}
      <button onclick="toggleUser('${u._id}', ${u.isActive !== false})">${u.isActive !== false ? 'Block' : 'Unblock'}</button>
    </li>
  `).join("");
}

async function toggleUser(id, currentlyActive) {
  await fetch(`http://localhost:5000/api/admin/users/${id}/block`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify({ isActive: !currentlyActive })
  });
  fetchUsers();
}

// ORDERS
async function fetchOrders() {
  const res = await fetch("http://localhost:5000/api/admin/orders", {
    headers: { Authorization: "Bearer " + token }
  });
  const orders = await res.json();
  const list = document.getElementById("orderList");
  list.innerHTML = orders.map(o => `
    <li>
      <b>Order #${o._id}</b> — ${o.userId?.name || 'N/A'} — ₹${o.total} — 
      <select onchange="changeOrderStatus('${o._id}', this.value)">
        ${["Placed","Processing","Shipped","Delivered","Cancelled"].map(s => `<option value="${s}" ${o.status===s?"selected":""}>${s}</option>`).join("")}
      </select>
      <div>Items: ${o.items.map(i => `${i.quantity}x ${i.bookId?.title || "Unknown"}`).join(", ")}</div>
    </li>
  `).join("");
}

async function changeOrderStatus(orderId, status) {
  await fetch(`http://localhost:5000/api/admin/orders/${orderId}/status`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify({ status })
  });
  fetchOrders();
}

// Initial load
showTab("books");
fetchBooks();
fetchUsers();
fetchOrders();

function logout() {
  localStorage.clear();
  window.location.href = "login.html";
}
