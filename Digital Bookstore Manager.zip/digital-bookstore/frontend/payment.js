document.getElementById("amount").textContent = localStorage.getItem("pay_amount");

async function processPayment() {
  const orderId = localStorage.getItem("pay_order_id");
  const token = localStorage.getItem("token");

  if (!orderId) {
    alert("Invalid order ID");
    return;
  }

  const res = await fetch("http://localhost:5000/api/payments/process", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + token
    },
    body: JSON.stringify({
      orderId,
      paymentMethod: "Card"
    })
  });

  const data = await res.json();

  if (data.success) {
    window.location.href = "payment-success.html";
  } else {
    alert("Payment failed");
  }
}