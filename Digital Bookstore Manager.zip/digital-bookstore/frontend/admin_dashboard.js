const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user"));
document.getElementById("adminName").textContent = user?.name || "Admin";

function showTab(name) {
  document.querySelectorAll(".tab-section").forEach(s => s.style.display = "none");
  document.getElementById(name).style.display = "block";
  document.querySelectorAll(".tabs button").forEach(b => b.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
}
async function loadAdminCategories() {
    const res = await fetch("http://localhost:5000/api/books/categories");
    const categories = await res.json();

    const container = document.getElementById("adminCategoryFilters");
    container.innerHTML = "";

    // Add ALL button
    container.innerHTML += `
        <button class="category-btn active" onclick="filterAdminBooks('All')">All</button>
    `;

    categories.forEach(cat => {
        container.innerHTML += `
            <button class="category-btn" onclick="filterAdminBooks('${cat}')">${cat}</button>
        `;
    });
}

async function filterAdminBooks(category) {
    document.querySelectorAll(".category-btn").forEach(b => b.classList.remove("active"));
    document.querySelector(`.category-btn[onclick="filterAdminBooks('${category}')"]`).classList.add("active");

    const res = await fetch("http://localhost:5000/api/books");
    const allBooks = await res.json();

    let filtered =
        category === "All"
            ? allBooks
            : allBooks.filter(b => b.category === category);

    fetchBooks(filtered);  
}


// BOOKS
async function fetchBooks(books) {
//   const res = await fetch("http://localhost:5000/api/books", {
//     headers: { Authorization: "Bearer " + token }
//   });
//   const books = await res.json();
//   const list = document.getElementById("bookList");

//   list.innerHTML = books.map(b => `
//   <div class="book-card">
//     <div class="book-card-header">${b.title}</div>
//     <div class="book-card-body">
//       <p><b>Author:</b> ${b.author}</p>
//       <p><b>Price:</b> ₹${b.price}</p>
//       <p><b>Stock:</b> ${b.stock}</p>
//       <p><b>⭐ Rating:</b> ${b.avgRating || 0} / 5 (${b.reviewsCount || 0} reviews)</p>
//       <button onclick="viewBookDetails('${b._id}')">👁 View Details</button>
//       <button onclick="editBook('${b._id}')">✏️ Edit</button>
//       <button onclick="deleteBook('${b._id}')">🗑️ Delete</button>
//     </div>
//   </div>
// `).join("");
const list = document.getElementById("bookList");
  // If no books passed → fetch all books
    if (!books) {
        const res = await fetch("http://localhost:5000/api/books");
        books = await res.json();
    }
    if (books.length === 0) {
        list.innerHTML = "<p>No books in this category.</p>";
        return;
    }

    list.innerHTML = books.map(b => `
        <div class="book-card">
     <div class="book-card-header">${b.title}</div>
     <div class="book-card-body">
       <p><b>Author:</b> ${b.author}</p>
       <p><b>Price:</b> ₹${b.price}</p>
       <p><b>Stock:</b> ${b.stock}</p>
       <p><b>⭐ Rating:</b> ${b.avgRating || 0} / 5 (${b.reviewsCount || 0} reviews)</p>
       <button onclick="viewBookDetails('${b._id}')">👁 View Details</button>
       <button onclick="editBook('${b._id}')">✏️ Edit</button>
       <button onclick="deleteBook('${b._id}')">🗑️ Delete</button>
     </div>
   </div>
 `).join("");
}
function openBookModal(editMode = false, book = null) {
  document.getElementById("bookModal").style.display = "flex";
  document.getElementById("modalTitle").textContent = editMode ? "Edit Book" : "Add Book";

  const form = document.getElementById("bookForm");
  if (editMode && book) {
    form.dataset.editId = book._id;
    document.getElementById("title").value = book.title;
    document.getElementById("author").value = book.author;
    document.getElementById("price").value = book.price;
    document.getElementById("category").value = book.category || "";
    document.getElementById("description").value = book.description || "";
    document.getElementById("stock").value = book.stock || 0;
  } else {
    form.reset();
    delete form.dataset.editId;
  }
}

function closeBookModal() {
  document.getElementById("bookModal").style.display = "none";
}

async function viewBookDetails(id) {
  const res = await fetch(`http://localhost:5000/api/books/${id}/reviews`, {
    headers: { Authorization: "Bearer " + token }
  });
  const data = await res.json();

  // Open modal
  const modal = document.createElement("div");
  modal.classList.add("modal");
  modal.style.display = "flex";
  modal.innerHTML = `
    <div class="modal-content">
      <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
      <h3>📖 Book Reviews</h3>
      <p><b>Average Rating:</b> ${data.avgRating} ⭐ (${data.reviewsCount} reviews)</p>
      <ul>
        ${data.reviews.map(r => `
          <li>
            <b>${r.name}</b> — ${r.rating}⭐ <br>
            ${r.comment || "No comment"} <br>
            <small>${new Date(r.createdAt).toLocaleString()}</small>
          </li>
        `).join("")}
      </ul>
    </div>
  `;
  document.body.appendChild(modal);
}


// async function openDetailsModal(bookId) {
//   try {
//     const res = await fetch(`http://localhost:5000/api/books/${bookId}`, {
//       headers: { Authorization: "Bearer " + token },
//     });
//     const book = await res.json();

//     // Fill book details
//     document.getElementById("detailsTitle").textContent = book.title;
//     document.getElementById("detailsAuthor").textContent = book.author;
//     document.getElementById("detailsPrice").textContent = book.price;
//     document.getElementById("detailsCategory").textContent = book.category || "N/A";
//     document.getElementById("detailsStock").textContent = book.stock;
//     document.getElementById("detailsDesc").textContent = book.description || "No description";

//     // Load reviews
//     const reviewsRes = await fetch(`http://localhost:5000/api/books/${bookId}/reviews`, {
//       headers: { Authorization: "Bearer " + token },
//     });
//     const reviews = await reviewsRes.json();

//     const reviewsList = document.getElementById("reviewsList");
//     if (reviews.length === 0) {
//       reviewsList.innerHTML = "<p>No reviews yet.</p>";
//     } else {
//       reviewsList.innerHTML = reviews.map(r => `
//         <div class="review-card">
//           <p><strong>${r.userId?.name || "Anonymous"}</strong> — ⭐ ${r.rating}</p>
//           <p>${r.comment}</p>
//         </div>
//       `).join("");
//     }

//     document.getElementById("bookDetailsModal").style.display = "block";
//   } catch (err) {
//     console.error("Error fetching book details:", err);
//   }
// }

// function closeDetailsModal() {
//   document.getElementById("bookDetailsModal").style.display = "none";
// }

document.getElementById("bookForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = e.target.dataset.editId;
  const body = {
    title: document.getElementById("title").value,
    author: document.getElementById("author").value,
    price: Number(document.getElementById("price").value),
    category: document.getElementById("category").value,
    description: document.getElementById("description").value,
    stock: Number(document.getElementById("stock").value)
  };
  const url = id ? `http://localhost:5000/api/books/${id}` : "http://localhost:5000/api/books";
  const method = id ? "PUT" : "POST";

  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify(body)
  });

  if (res.ok) {
    alert(id ? "Book updated" : "Book added");
    closeBookModal();
    fetchBooks();
  } else {
    alert("Failed to save book");
  }
});

async function editBook(id) {
  const res = await fetch(`http://localhost:5000/api/books/${id}`, {
    headers: { Authorization: "Bearer " + token }
  });
  const b = await res.json();
  openBookModal(true, b);
}

async function deleteBook(id) {
  if (!confirm("Delete this book?")) return;
  const res = await fetch(`http://localhost:5000/api/books/${id}`, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token }
  });
  if (res.ok) fetchBooks();
}

// USERS
// async function fetchUsers() {
//   const res = await fetch("http://localhost:5000/api/admin/users", {
//     headers: { Authorization: "Bearer " + token }
//   });
//   const users = await res.json();
//   const list = document.getElementById("userList");
//   list.innerHTML = users.map(u => `
//     <li>
//       ${u.name} — ${u.email} — Role: ${u.role} — Active: ${u.isActive !== false}
//       <button onclick="toggleUser('${u._id}', ${u.isActive !== false})">${u.isActive !== false ? 'Block' : 'Unblock'}</button>
//     </li>
//   `).join("");
// }

async function fetchUsers() {
  const res = await fetch("http://localhost:5000/api/admin/users", {
    headers: { Authorization: "Bearer " + token }
  });
  let users = await res.json();
  const list = document.getElementById("userList");
users = users.filter(u => u.role === "customer");
  list.innerHTML = `
    <table class="user-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        ${users.map(u => `
          <tr>
            <td>${u.name}</td>
            <td>${u.email}</td>
            <td>${u.role}</td>
            <td>${u.isActive !== false ? "Active ✅" : "Blocked ❌"}</td>
            <td>
              <button onclick="toggleUser('${u._id}', ${u.isActive !== false})">
                ${u.isActive !== false ? 'Block' : 'Unblock'}
              </button>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

async function toggleUser(id, currentlyActive) {
  await fetch(`http://localhost:5000/api/admin/users/${id}/block`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + localStorage.getItem("token") },
    body: JSON.stringify({ isActive: !currentlyActive })
  });
  fetchUsers();
}

let allOrders = [];  // store all orders here
// ORDERS
// async function fetchOrders() {
//   // const res = await fetch("http://localhost:5000/api/orders/admin", {
//   //   headers: { Authorization: "Bearer " + token }
//   // });
//   const status = document.getElementById("statusFilter").value;
//   let url = "http://localhost:5000/api/orders/admin";
//   // let url = "http://localhost:5000/api/admin/orders";

//   if (status !== "All") {
//     url += `?status=${status}`;
//   }
//   console.log(status,url);
//   const token = localStorage.getItem("token");
//   console.log(token);
//   const res = await fetch(url, {
//     headers: { Authorization: "Bearer " + token }
//   });
// // const res = await fetch(url, {
// //   method: "GET",
// //   headers: {
// //     "Content-Type": "application/json",
// //     "x-auth-token": token
// //   }
// // });
//   const orders = await res.json();
//    console.log("📦 Orders received:", orders);
//     // let orders = await res.json();
//   // const status = document.getElementById("statusFilter").value;

//   // 👉 filter on frontend
//   // if (status !== "All") {
//   //   orders = orders.filter(o => o.status === status);
//   // }

//   // renderOrders(orders, status);

//   const list = document.getElementById("orderList");
//   if (!orders.length) {
//     list.innerHTML = `<p style="text-align:center; color:gray;">No orders found for "${status}"</p>`;
//     return;
//   }

//   list.innerHTML = orders.map(o => `
//     <div class="order-card">
//       <div class="order-header">
//         <h4>Order #${o._id.slice(-5).toUpperCase()}</h4>
//         <select class="status-dropdown" onchange="changeOrderStatus('${o._id}', this.value)">
//           ${["Placed", "Processing", "Shipped", "Delivered", "Cancelled"]
//             .map(s => `<option value="${s}" ${o.status === s ? "selected" : ""}>${s}</option>`).join("")}
//         </select>
//       </div>
//       <div class="order-body">
//         <p><b>👤 Customer:</b> ${o.userId?.name || "N/A"} (${o.userId?.email || "N/A"})</p>
//         <p><b>💰 Total:</b> ₹${o.total}</p>
//         <p><b>📅 Date:</b> ${new Date(o.createdAt).toLocaleString()}</p>
//         <div class="order-items">
//           <b>Items:</b><br>
//           ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})`).join("<br>")}
//         </div>
//       </div>
//     </div>
//   `).join("");
// }
async function fetchOrders() {
  const token = localStorage.getItem("token");

  const res = await fetch("http://localhost:5000/api/orders/admin", {
    headers: { Authorization: "Bearer " + token }
  });

  allOrders = await res.json();  // store all orders
  console.log("📦 All Orders Loaded:", allOrders);

  renderOrders(allOrders); // display immediately
}
function renderOrders(orders) {
  const list = document.getElementById("orderList");

  if (!orders.length) {
    list.innerHTML = `<p style="text-align:center; color:gray;">No orders found</p>`;
    return;
  }

  list.innerHTML = orders.map(o => `
    <div class="order-card">
      <div class="order-header">
        <h4>Order #${o._id.slice(-5).toUpperCase()}</h4>
        <select class="status-dropdown" onchange="changeOrderStatus('${o._id}', this.value)">
          ${["Placed", "Processing", "Shipped", "Delivered", "Cancelled"]
            .map(s => `<option value="${s}" ${o.status === s ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </div>
      <div class="order-body">
        <p><b>👤 Customer:</b> ${o.userId?.name || "N/A"} (${o.userId?.email || "N/A"})</p>
        <p><b>💰 Total:</b> ₹${o.total}</p>
        <p><b>📅 Date:</b> ${new Date(o.createdAt).toLocaleString()}</p>
        <div class="order-items">
          <b>Items:</b><br>
          ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})`).join("<br>")}
        </div>
      </div>
    </div>
  `).join("");
}
function filterOrders() {
  const status = document.getElementById("statusFilter").value;

  if (status === "All") {
    renderOrders(allOrders);
  } else {
    const filtered = allOrders.filter(order => order.status === status);
    console.log(filtered);
    renderOrders(filtered);
  }
  
}

function searchOrders() {
  const text = document.getElementById("orderSearchInput").value.trim().toLowerCase();

  // 1. Apply search filter on loaded orders
  const searched = allOrders.filter(order =>
    order._id.toLowerCase().includes(text) ||
    order.userId?.name?.toLowerCase().includes(text) ||
    order.userId?.email?.toLowerCase().includes(text)
  );

  // 2. Apply status filter on top of search
  const status = document.getElementById("statusFilter").value;
  let finalResults = searched;

  if (status !== "All") {
    finalResults = searched.filter(o => o.status === status);
  }

  renderOrders(finalResults);
}






// function renderOrders(order,status){
// const list = document.getElementById("orderList");
//   if (!orders.length) {
//     list.innerHTML = `<p style="text-align:center; color:gray;">No orders found for "${status}"</p>`;
//     return;
//   }

//   list.innerHTML = orders.map(o => `
//     <div class="order-card">
//       <div class="order-header">
//         <h4>Order #${o._id.slice(-5).toUpperCase()}</h4>
//         <select class="status-dropdown" onchange="changeOrderStatus('${o._id}', this.value)">
//           ${["Placed", "Processing", "Shipped", "Delivered", "Cancelled"]
//             .map(s => `<option value="${s}" ${o.status === s ? "selected" : ""}>${s}</option>`).join("")}
//         </select>
//       </div>
//       <div class="order-body">
//         <p><b>👤 Customer:</b> ${o.userId?.name || "N/A"} (${o.userId?.email || "N/A"})</p>
//         <p><b>💰 Total:</b> ₹${o.total}</p>
//         <p><b>📅 Date:</b> ${new Date(o.createdAt).toLocaleString()}</p>
//         <div class="order-items">
//           <b>Items:</b><br>
//           ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})`).join("<br>")}
//         </div>
//       </div>
//     </div>
//   `).join("");
// }


// ✅ Update Order Status
async function changeOrderStatus(orderId, status) {
  const res = await fetch(`http://localhost:5000/api/orders/${orderId}/status`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    body: JSON.stringify({ status })
  });

  if (res.ok) {
    alert("✅ Order status updated");
    fetchOrders();
  } else {
    alert("❌ Failed to update order status");
  }
}

// Initial load
async function initAdminDashboard() {
showTab("books");
fetchBooks();
// fetchBooks(filtered);
fetchUsers();
fetchOrders();
await loadAdminCategories();
filterAdminBooks("All");
}
initAdminDashboard()
function logout() {
  localStorage.clear();
  window.location.href = "login.html";
}
// === Utility: Get Token from localStorage (saved at login) ===
// const token = localStorage.getItem("token");

// Show Books in the grid
// async function fetchBooks() {
//   try {
//     const res = await fetch("http://localhost:5000/api/books", {
//       headers: {
//         Authorization: `Bearer ${token}`,
//       },
//     });

//     const books = await res.json();
//     const bookList = document.getElementById("bookList");
//     bookList.innerHTML = "";

//     books.forEach((book) => {
//       const div = document.createElement("div");
//       div.className = "book-card";
//       div.innerHTML = `
//         <h4>${book.title}</h4>
//         <p><strong>Author:</strong> ${book.author}</p>
//         <p><strong>Price:</strong> $${book.price}</p>
//         <p><strong>Category:</strong> ${book.category}</p>
//         <p><strong>Stock:</strong> ${book.stock}</p>
//         <button onclick="deleteBook('${book._id}')">🗑 Delete</button>
//       `;
//       bookList.appendChild(div);
//     });
//   } catch (err) {
//     console.error(err);
//   }
// }
// async function fetchBooks() {
//   try {
//     const res = await fetch("http://localhost:5000/api/books", {
//       headers: {
//         Authorization: `Bearer ${token}`,
//       },
//     });

//     const books = await res.json();
//     const bookList = document.getElementById("bookList");
//     bookList.innerHTML = "";

//     books.forEach((book) => {
//       const div = document.createElement("div");
//       div.className = "book-card";
//       div.innerHTML = `
//         <h4>${book.title}</h4>
//         <p><strong>Author:</strong> ${book.author}</p>
//         <p><strong>Price:</strong> ₹${book.price}</p>
//         <button onclick="openDetailsModal('${book._id}')">📖 View Details</button>
//         <button onclick="deleteBook('${book._id}')">🗑 Delete</button>
//       `;
//       bookList.appendChild(div);
//     });
//   } catch (err) {
//     console.error(err);
//   }
// }
// async function openDetailsModal(bookId) {
//   try {
//     const res = await fetch(`http://localhost:5000/api/books/${bookId}`, {
//       headers: { Authorization: `Bearer ${token}` },
//     });
//     const book = await res.json();

//     document.getElementById("detailsTitle").textContent = book.title;
//     document.getElementById("detailsAuthor").textContent = book.author;
//     document.getElementById("detailsPrice").textContent = book.price;
//     document.getElementById("detailsCategory").textContent = book.category || "N/A";
//     document.getElementById("detailsStock").textContent = book.stock;
//     document.getElementById("detailsDesc").textContent = book.description || "No description";

//     document.getElementById("bookDetailsModal").style.display = "block";
//   } catch (err) {
//     console.error("Error fetching book details:", err);
//   }
// }

// // === Close Modal ===
// function closeDetailsModal() {
//   document.getElementById("bookDetailsModal").style.display = "none";
// }
// // === Add Book ===
// document.getElementById("bookForm").addEventListener("submit", async (e) => {
//   e.preventDefault();

//   const newBook = {
//     title: document.getElementById("title").value,
//     author: document.getElementById("author").value,
//     price: document.getElementById("price").value,
//     category: document.getElementById("category").value,
//     description: document.getElementById("description").value,
//     stock: document.getElementById("stock").value,
//   };

//   try {
//     const res = await fetch("http://localhost:5000/api/books", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Bearer ${token}`,
//       },
//       body: JSON.stringify(newBook),
//     });

//     if (res.ok) {
//       alert("✅ Book added successfully!");
//       closeBookModal();
//       fetchBooks(); // refresh the grid
//     } else {
//       const data = await res.json();
//       alert("❌ " + data.msg);
//     }
//   } catch (err) {
//     console.error(err);
//     alert("Something went wrong!");
//   }
// });

// // === Delete Book ===
// async function deleteBook(id) {
//   if (!confirm("Are you sure you want to delete this book?")) return;

//   try {
//     const res = await fetch(`http://localhost:5000/api/books/${id}`, {
//       method: "DELETE",
//       headers: {
//         Authorization: `Bearer ${token}`,
//       },
//     });

//     if (res.ok) {
//       alert("🗑 Book deleted");
//       fetchBooks();
//     } else {
//       alert("❌ Failed to delete book");
//     }
//   } catch (err) {
//     console.error(err);
//   }
// }

// // === Tabs navigation ===
// function showTab(tabId) {
//   document.querySelectorAll(".tab-section").forEach((sec) => (sec.style.display = "none"));
//   document.querySelectorAll(".tabs button").forEach((btn) => btn.classList.remove("active"));

//   document.getElementById(tabId).style.display = "block";
//   document.querySelector(`[data-tab="${tabId}"]`).classList.add("active");

//   if (tabId === "books") fetchBooks();
// }

// // === Modal controls ===
// function openBookModal() {
//   document.getElementById("bookModal").style.display = "block";
// }

// function closeBookModal() {
//   document.getElementById("bookModal").style.display = "none";
// }

// // === On page load, show Books tab ===
// window.onload = () => {
//   showTab("books");
// };
