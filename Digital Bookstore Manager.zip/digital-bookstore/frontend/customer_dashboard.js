const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user"));
document.getElementById("customerName").textContent = user?.name || "Customer";

// Show Tabs
function showTab(name) {
  document.querySelectorAll(".tab-section").forEach(s => s.style.display = "none");
  document.getElementById(name).style.display = "block";
  document.querySelectorAll(".tabs button").forEach(b => b.classList.remove("active"));
  document.querySelector(`[data-tab="${name}"]`).classList.add("active");
  if (name === "cart") {
      if (cart.length > 0) {
          const lastBook = cart[cart.length - 1].id;
          loadRecommendationsPopup(lastBook);
      }
  }
}
async function loadRecommendations(bookId) {
  console.log("Loading recommendations for book:", bookId);  
    try {
        const res = await fetch(`http://localhost:5000/api/books/${bookId}/recommend`);
        const data = await res.json();

        const container = document.getElementById("recommendations");
        container.innerHTML = "";  // clear old results

        if (data.length === 0) {
            container.innerHTML = "<p>No recommendations available.</p>";
            return;
        }

        data.forEach(book => {
            container.innerHTML += `
                <div class="recommend-card">
                    <h4>${book.title}</h4>
                    <p>Price: ₹${book.price}</p>
                    <p>Co-bought: ${book.count} times</p>
                    <button onclick="viewBook('${book._id}')">View</button>
                    <button onclick="addToCartFromRecommend('${book._id}')">Add to Cart</button>
                    </div>
            `;
        });
    } catch (err) {
        console.log("Recommendation error:", err);
    }
}

async function addToCartFromRecommend(bookId) {
    try {
        const customer = JSON.parse(localStorage.getItem("customer"));
        if (!customer) return alert("Login again!");

        const res = await fetch("http://localhost:5000/api/cart/add", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId: customer._id, bookId })
        });

        const data = await res.json();
        alert("Book added to cart!");
    } catch (err) {
        console.log("Add to cart error:", err);
    }
}

// Call it when page loads
// const urlParams = new URLSearchParams(window.location.search);
// loadRecommendations(urlParams.get("id"));

// ---------------- BOOKS ----------------
async function fetchBooks() {
  const res = await fetch("http://localhost:5000/api/books");
  const books = await res.json();
  const list = document.getElementById("bookList");

  list.innerHTML = books.map(b => `
    <div class="book-card">
      <h4>${b.title}</h4>
      <p><b>Author:</b> ${b.author}</p>
      <p><b>Price:</b> ₹${b.price}</p>
      <p><b>Stock:</b> ${b.stock}</p>
       <button onclick="viewBookDetails('${b._id}')">👁 View Details</button>
      <button onclick="addToCart('${b._id}', '${b.title}', ${b.price})">🛒 Add to Cart</button>
      </div>
  `).join("");
}
// <button onclick="viewBook('${b._id}')">👁 View Details</button>

// ---------------- CART ----------------
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(id, title, price) {
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id, title, price, qty: 1 });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${title} added to cart`);
  showCart();

  // loadRecommendationsPopup(id);ss
}

function showCart() {
  const cartDiv = document.getElementById("cartItems");
  if (cart.length === 0) {
    cartDiv.innerHTML = "<p>No items in cart</p>";
    return;
  }

  let total = 0;
  cartDiv.innerHTML = cart.map(item => {
    total += item.price * item.qty;
    return `
      <div class="cart-item">
        <b>${item.title}</b> - ₹${item.price} × ${item.qty}
        <button onclick="removeFromCart('${item.id}')">❌</button>
      </div>
    `;
  }).join("");

  cartDiv.innerHTML += `<h4>Total: ₹${total}</h4>`;
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  localStorage.setItem("cart", JSON.stringify(cart));
  showCart();
}

// ---------------- ORDERS ----------------
document.getElementById("placeOrderBtn").addEventListener("click", async () => {
  if (cart.length === 0) return alert("Cart is empty!");

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const formattedItems = cart.map(item => ({
  bookId: item.id,       // backend expects bookId
  title: item.title,
  price: item.price,
  quantity: item.qty      // backend expects quantity
}));
  const res = await fetch("http://localhost:5000/api/payments/initiate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    body: JSON.stringify({ items: formattedItems, total })
  });
const data = await res.json();

  if (res.ok) {
    // alert("✅ Order placed successfully!");
    localStorage.setItem("pay_order_id", data.orderId);
  localStorage.setItem("pay_amount", total);
  
localStorage.setItem("pendingOrderId", data.orderId);
    cart = [];
    localStorage.removeItem("cart");
    showCart();
     window.location.href = "payment.html";
    // fetchOrders();
  } else {
    alert("❌ Failed to place order.");
  }
});
// 🧾 Fetch My Orders
async function fetchOrders() {
  const token = localStorage.getItem("token");

  const res = await fetch("http://localhost:5000/api/orders/my", {
    headers: { Authorization: "Bearer " + token }
  });
 console.log("Response status:", res.status); 
  const orders = await res.json();
  console.log("Orders data:", orders);
  const list = document.getElementById("myOrdersList");

  if (!orders.length) {
    list.innerHTML = "<p>No orders found yet!</p>";
    return;
  }
  list.innerHTML = orders.map(o => `
    <div class="order-card">
      <div class="order-header">
        <h4>Order #${o._id.slice(-5).toUpperCase()}</h4>
      </div>
      <div class="order-body">
        <p><b>Status:</b> ${o.status}</p>
        <p><b>Total:</b> ₹${o.total}</p>
        <p><b>Placed on:</b> ${new Date(o.createdAt).toLocaleString()}</p>
        <button class="invoice-btn" onclick="downloadInvoice('${o._id}')">
            🧾 Download Invoice
        </button>
        <div class="items-list">
          <b>Items:</b><br>
          ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})<button class="write-review-btn" onclick="openReviewModal('${i.id}', '${i.title.replace(/'/g, "\\'")}')">
          
    ✍️ Write Review </button>`).join("<br>")}
        </div>
      </div>
    </div>
  `).join("");

//   document.querySelectorAll(".write-review-btn").forEach(btn => {
//     btn.addEventListener("click", (e) => {
//       const bookId = e.target.dataset.bookid;
//       const title = e.target.dataset.title;
//       openReviewModal(bookId, title);
//     });
//   });
}
// data-bookid="${i.id}" data-title="${i.title}
// function openReviewModal(bookId, title) {
//   document.getElementById("reviewBookId").value = bookId;
//   document.getElementById("reviewBookTitle").innerText = `Review for: ${title}`;
//   document.getElementById("reviewModal").style.display = "flex";
// }

// document.getElementById("closeModal").onclick = () => {
//   document.getElementById("reviewModal").style.display = "none";
// };

// document.getElementById("reviewForm").onsubmit = async (e) => {
//   e.preventDefault();

//   const bookId = document.getElementById("reviewBookId").value;
//   const rating = document.getElementById("rating").value;
//   const comment = document.getElementById("comment").value;
//   const token = localStorage.getItem("token");

//   const res = await fetch(`http://localhost:5000/api/books/${bookId}/reviews`, {
//     method: "POST",
//     headers: {
//       "Content-Type": "application/json",
//       Authorization: "Bearer " + token
//     },
//     body: JSON.stringify({ rating, comment })
//   });

//   const data = await res.json();

//   if (res.ok) {
//     alert("✅ Review submitted successfully!");
//     document.getElementById("reviewModal").style.display = "none";
//     document.getElementById("reviewForm").reset();
//   } else {
//     alert("❌ " + (data.msg || "Failed to submit review"));
//   }
// };
function downloadInvoice(orderId) {
  // console.log("ORDER RECEIVED FOR INVOICE:", order);
  const token = localStorage.getItem("token");
  fetch(`http://localhost:5000/api/invoice/invoice/${orderId}`, {
    method: "GET",
    headers: {
      "Authorization": "Bearer " + token
    }
  })
  .then(response => response.blob())
  .then(blob => {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Invoice_${orderId}.pdf`;
    a.click();
  });
}


let currentBookId = null; // To store which book the user is reviewing

function openReviewModal(bookId, title) {
  console.log("Opening review modal for:", bookId, title); 
  if (!bookId || !title) {
    alert("⚠️ Review cannot be added for this book (missing data).");
    return;
  }
  currentBookId = bookId;
  document.getElementById("reviewBookTitle").textContent = `Review for: ${title}`;
  document.getElementById("rating").value = "";
  document.getElementById("comment").value = "";
  document.getElementById("reviewModal").style.display = "flex";
}

function closeReviewModal() {
  document.getElementById("reviewModal").style.display = "none";
}

async function submitReview() {
  const rating = document.getElementById("rating").value;
  const comment = document.getElementById("comment").value;
  const token = localStorage.getItem("token");

  if (!rating || !comment) {
    alert("Please enter both rating and comment.");
    return;
  }

  const res = await fetch(`http://localhost:5000/api/books/${currentBookId}/reviews`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + token
    },
    body: JSON.stringify({ rating, comment })
  });

  if (res.ok) {
    alert("Review submitted successfully!");
    closeReviewModal();
  } else {
    const err = await res.json();
    alert("Failed to submit review: " + (err.message || res.statusText));
  }
}

//<b>Items:</b><br>
  //        ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})`).join("<br>")}
// async function fetchOrders() {
//   const res = await fetch("http://localhost:5000/api/orders/my", {
//     headers: { Authorization: "Bearer " + token }
//   });
//   const orders = await res.json();

//   const list = document.getElementById("orderList");
//   if (orders.length === 0) {
//     list.innerHTML = "<p>No orders yet.</p>";
//     return;
//   }

//   list.innerHTML = orders.map(o => `
//     <div class="order-item">
//       <b>Order ID:</b> ${o._id}<br>
//       <b>Total:</b> ₹${o.total}<br>
//       <b>Status:</b> ${o.status}<br>
//       <b>Date:</b> ${new Date(o.createdAt).toLocaleString()}
//     </div>
//   `).join("");
// }
// ---------------- LOGOUT ----------------
function viewBook(bookId) {
  console.log("Viewing book:", bookId);

  // Show the recommendations tab
  showTab("recommendationsTab");

  // Load recommendations
  loadRecommendations(bookId);
  //  showTab("recommendationsTab");

}
async function viewBookDetails(bookId) {
  console.log("Viewing book:", bookId);

  const res = await fetch(`http://localhost:5000/api/books/${bookId}`);
  const book = await res.json();

  // Show details
  document.getElementById("detailTitle").textContent = book.title;
  document.getElementById("detailAuthor").textContent = book.author;
  document.getElementById("detailPrice").textContent = book.price;
  document.getElementById("detailCategory").textContent = book.category || "N/A";
  document.getElementById("detailDescription").textContent =
    book.description || "No description available";

  const avgRating = book.reviews?.length
    ? (book.reviews.reduce((a, r) => a + r.rating, 0) / book.reviews.length).toFixed(1)
    : null;

  // document.getElementById("detailRating").innerHTML =
  //   avg ? `⭐ <b>${avg}</b> (${book.reviews.length} reviews)` : "No ratings yet";
  let ratingHTML = avgRating
    ? `<h4>⭐ ${avgRating} / 5 (${book.reviews.length} reviews)</h4>`
    : "<h4>No Ratings Yet</h4>";

  // Full Review List
  let reviewListHTML = "";
  if (book.reviews && book.reviews.length > 0) {
    reviewListHTML = book.reviews
      .map(
        r => `
      <div class="review-box">
        <div class="review-rating">⭐ ${r.rating}/5</div>
        <div class="review-text">${r.comment}</div>
        <small><i>- ${r.user || "Anonymous"}</i></small>
      </div>
    `
      )
      .join("");
  } else {
    reviewListHTML = "<p>No reviews available.</p>";
  }

  document.getElementById("detailReviews").innerHTML =
    ratingHTML + reviewListHTML;
  // Display popup
  document.getElementById("bookDetailModal").style.display = "flex";
}

async function loadCategories() {
  const res = await fetch("http://localhost:5000/api/books/categories");
  const categories = await res.json();

  const bar = document.getElementById("categoryBar");

  bar.innerHTML = `
    <button class="category-btn active" onclick="filterByCategory('All')">All</button>
  `;

  categories.forEach(cat => {
    bar.innerHTML += `
      <button class="category-btn active" onclick="filterByCategory('${cat}')">${cat}</button>
    `;
  });
}
function setActiveCategory(cat) {
  document.querySelectorAll(".category-btn").forEach(btn => btn.classList.remove("active"));
  document.querySelector(`.category-btn:nth-child(${cat === 'All' ? 1 : 0})`);
}

async function filterByCategory(category) {
  setActiveCategory(category);

  if (category === "All") return fetchBooks();

  const res = await fetch(`http://localhost:5000/api/books/category/${category}`);
  const books = await res.json();

  const list = document.getElementById("bookList");

  list.innerHTML = books.length
    ? books.map(b => `
      <div class="book-card">
        <h4>${b.title}</h4>
        <p><b>Author:</b> ${b.author}</p>
        <p><b>Category:</b> ${b.category}</p>
        <p><b>Price:</b> ₹${b.price}</p>
        <p><b>Stock:</b> ${b.stock}</p>
        <button onclick="viewBookDetails('${b._id}')">👁 View Details</button>
        <button onclick="addToCart('${b._id}', '${b.title}', ${b.price})">🛒 Add to Cart</button>
      </div>
    `)
    : `<p>No books found in ${category}</p>`;
}

function closeBookDetail() {
  document.getElementById("bookDetailModal").style.display = "none";
}

function logout() {
  localStorage.clear();
  window.location.href = "login.html";
}
// ⭐ Popup Recommendation Loader
function loadRecommendationsPopup(bookId) {
    fetch(`http://localhost:5000/api/books/${bookId}/recommend`)
        .then(res => res.json())
        .then(recos => {
            let container = document.getElementById("recommendationModalContent");
            container.innerHTML = "";

            if (!recos.length) {
                container.innerHTML = "<p>No recommendations available.</p>";
            } else {
                recos.forEach(book => {
                    container.innerHTML += `
                        <div class="rec-card">
                            <h3>${book.title}</h3>
                            <p>Price: ₹${book.price}</p>
                            <button onclick="addToCart('${book._id}', '${book.title}', ${book.price})">
                                Add to Cart
                            </button>
                        </div>
                    `;
                });
            }

            document.getElementById("recommendationModal").style.display = "flex";
        })
        .catch(err => console.log("Recommendation popup error:", err));
}
function openRecommendationModal() {
    document.getElementById("recommendationModal").style.display = "flex";
}

function closeRecommendationModal() {
    document.getElementById("recommendationModal").style.display = "none";
}

let allBooks = [];

async function loadBooks() {
  const res = await fetch("http://localhost:5000/api/books");
  allBooks = await res.json();
  displayBooks(allBooks);
}

async function searchBooks() {
  let query = document.getElementById("bookSearch").value.toLowerCase();

  const results = allBooks.filter(book => 
    book.title.toLowerCase().includes(query) ||
    book.author.toLowerCase().includes(query) ||
    book.category?.toLowerCase().includes(query)
  );
  // const res = await fetch(`http://localhost:5000/api/books?search=${query}`);
  // const data = await res.json();
  displayBooks(results);
}

function displayBooks(books) {
  const container = document.getElementById("bookList");

  if (!books.length) {
    container.innerHTML = `<p style="color:red; text-align:center;">No books found!</p>`;
    return;
  }

  container.innerHTML = books.map(b => `
   <div class="book-card">
        <h4>${b.title}</h4>
        <p><b>Author:</b> ${b.author}</p>
        <p><b>Category:</b> ${b.category}</p>
        <p><b>Price:</b> ₹${b.price}</p>
        <p><b>Stock:</b> ${b.stock}</p>
        <button onclick="viewBookDetails('${b._id}')">👁 View Details</button>
        <button onclick="addToCart('${b._id}', '${b.title}', ${b.price})">🛒 Add to Cart</button>
      </div>
  `).join("");
}

loadBooks();

// Initial Load
showTab("books");
fetchBooks();
showCart();
fetchOrders();
loadCategories();
// window.onload = function () {
//   const params = new URLSearchParams(window.location.search);
//   const tab = params.get("tab");

//   if (tab === "orders") {
//     document.getElementById("placeOrderBtn").click();  
//   }
// };