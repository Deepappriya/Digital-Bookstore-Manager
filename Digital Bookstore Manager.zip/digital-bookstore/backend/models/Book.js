const mongoose = require("mongoose");

// Review schema (embedded inside Book)
const ReviewSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now }
});

const BookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  price: { type: Number, required: true },
  category: { type: String },
  description: { type: String },
  stock: { type: Number, default: 0 },

  // New fields for reviews
  reviews: [ReviewSchema],
  avgRating: { type: Number, default: 0 },
  reviewsCount: { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Book", BookSchema);
