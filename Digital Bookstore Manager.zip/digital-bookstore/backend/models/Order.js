const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [
      
      {
      bookId: {  type: mongoose.Schema.Types.ObjectId,ref: "Book" },
      title: { type: String },
      price: { type: Number },
      qty: { type: Number }
    }
  ],
  total: { type: Number, required: true },
  status: {
    type: String,
    enum: ["Pending","Placed", "Processing", "Shipped", "Delivered", "Cancelled"],
    default: "Pending"
  },
  // 🔥 Added fields
    paymentStatus: { type: String, default: "Pending" },
    paymentMethod: { type: String, default: "None" },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Order", OrderSchema);
