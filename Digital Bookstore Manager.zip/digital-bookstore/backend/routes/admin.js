const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Order = require("../models/Order");
const auth = require("../middleware/auth");
const isAdmin = require("../middleware/isAdmin");

// 1) Get all users
router.get("/users", auth, isAdmin, async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

// 2) Block/Unblock user
router.patch("/users/:id/block", auth, async (req, res) => {
  // try {
  //   const user = await User.findById(req.params.id);
  //   if (!user) return res.status(404).json({ msg: "User not found" });
  //   user.isActive = req.body.isActive !== false; // toggle
  //   await user.save();
  //   res.json({ msg: "User updated", user: { id: user._id, isActive: user.isActive } });
  // } catch (err) {
  //   res.status(500).json({ msg: "Server error" });
  // }
  try {
    // Only admin can block/unblock
    if (req.user.role !== "admin") {
      return res.status(403).json({ msg: "Access denied" });
    }
    const { isActive } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isActive: req.body.isActive },
      { new: true }
    );

    if (!user) return res.status(404).json({ msg: "User not found" });

    res.json({ msg: "User updated", user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3) Get all orders
router.get("/orders", auth, isAdmin, async (req, res) => {
  try {
    // console.log("🔥 ADMIN ORDERS API HIT | status =", req.query.status);
    let filter = {};

    // If status is passed in query (e.g., ?status=Delivered)
    if (req.query.status && req.query.status !== "All" &&req.query.status !== "undefined" && req.query.status.trim() !== "") {
      filter.status = req.query.status;
    }
    const search = req.query.search || "";

    const orders = await Order.find(filter)
      .populate("userId", "name email")
      .populate("items.bookId", "title author");
        // If search text entered → filter here
    if (search.trim() !== "") {
      orders = orders.filter(order =>
        order._id.toString().includes(search) ||
        order.userId?.name?.toLowerCase().includes(search.toLowerCase()) ||
        order.userId?.email?.toLowerCase().includes(search.toLowerCase())
      );
    }
    res.json(orders);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
}); 

// 4) Update order status
router.put("/orders/:id/status", auth, isAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ msg: "Order not found" });

    order.status = status;
    await order.save();
    res.json({ msg: "Order status updated", order });
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
