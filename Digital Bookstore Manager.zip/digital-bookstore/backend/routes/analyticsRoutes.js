// const express = require("express");
// const router = express.Router();
// const Order = require("../models/Order");
// const Book = require("../models/Book");
// const analyticsController = require('../controllers/analyticsController');

// console.log("Analytics Routes Loaded");

// // 1. Top 10 selling books
// router.get("/top-selling", async (req, res) => {
//   try {
//     const data = await Order.aggregate([
//       { $unwind: "$items" },
//       {
//         $group: {
//           _id: "$items.bookId",
//           totalSold: { $sum: "$items.quantity" }
//         }
//       },
//       {
//         $lookup: {
//           from: "books",
//           localField: "_id",
//           foreignField: "_id",
//           as: "bookDetails"
//         }
//       },
//       { $unwind: "$bookDetails" },
//       { $sort: { totalSold: -1 } },
//       { $limit: 10 }
//     ]);

//     res.json(data);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });
// // router.get('/top-books', analyticsController.getTopBooks);

// // 2. Monthly revenue
// router.get("/monthly-revenue", async (req, res) => {
//   try {
//     const data = await Order.aggregate([
//       {
//         $group: {
//           _id: { $month: "$createdAt" },
//           revenue: { $sum: "$totalAmount" },
//         },
//       },
//       { $sort: { _id: 1 } },
//     ]);

//     res.json(data);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // 3. Category wise sales
// router.get("/category-sales", async (req, res) => {
//   try {
//     const data = await Order.aggregate([
//       { $unwind: "$items" },
//       {
//         $lookup: {
//           from: "books",
//           localField: "items.bookId",
//           foreignField: "_id",
//           as: "bookDetails"
//         }
//       },
//       { $unwind: "$bookDetails" },
//       {
//         $group: {
//           _id: "$bookDetails.category",
//           totalSold: { $sum: "$items.quantity" }
//         }
//       },
//       { $sort: { totalSold: -1 } }
//     ]);

//     res.json(data);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // 4. Most reviewed books
// router.get("/most-reviewed", async (req, res) => {
//   try {
//     const data = await Book.aggregate([
//       {
//         $addFields: {
//           totalReviews: { $size: "$reviews" }
//         }
//       },
//       { $sort: { totalReviews: -1 } },
//       { $limit: 10 }
//     ]);

//     res.json(data);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // 5. Average order value
// router.get("/average-order-value", async (req, res) => {
//   try {
//     const data = await Order.aggregate([
//       {
//         $group: {
//           _id: null,
//           avgOrderValue: { $avg: "$totalAmount" }
//         }
//       }
//     ]);

//     res.json(data[0]);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// module.exports = router;
const express = require("express");
const router = express.Router();
const Order = require("../models/Order");
const Book = require("../models/Book");

// --------------------------------------------
// 1️⃣ TOP SELLING BOOKS
// --------------------------------------------
router.get("/top-selling", async (req, res) => {
  try {
    const data = await Order.aggregate([
      { $unwind: "$items" },

      // use id instead of bookId & qty instead of quantity
      {
        $group: {
          _id: "$items.id",
          totalSold: { $sum: { $ifNull: ["$items.qty", 1] } }
        }
      },

      {
        $lookup: {
          from: "books",
          localField: "_id",
          foreignField: "_id",
          as: "bookDetails"
        }
      },
      { $unwind: "$bookDetails" },
      { $sort: { totalSold: -1 } },
      { $limit: 10 }
    ]);

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------
// 2️⃣ MONTHLY REVENUE
// --------------------------------------------
router.get("/monthly-revenue", async (req, res) => {
  try {
    // const data = await Order.aggregate([
    //   {
    //     $group: {
    //       _id: { $month: "$createdAt" },
    //       revenue: { $sum: "$totalAmount" } // works fine
    //     }
    //   },
    //   { $sort: { _id: 1 } }
    // ]);
    const revenue = await Order.aggregate([
  {
    $unwind: "$items"
  },
  {
    $group: {
      _id: { $month: "$createdAt" },
      revenue: {
        $sum: { $multiply: [ "$items.price", "$items.qty" ] }
      }
    }
  },
  { $sort: { _id: 1 } }
]);
    res.json(revenue);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------
// 3️⃣ CATEGORY WISE SALES
// --------------------------------------------
router.get("/category-sales", async (req, res) => {
  try {
    const data = await Order.aggregate([
      { $unwind: "$items" },

      {
        $lookup: {
          from: "books",
          localField: "items.id",   // ← FIXED
          foreignField: "_id",
          as: "bookDetails"
        }
      },

      { $unwind: "$bookDetails" },

      {
        $group: {
          _id: "$bookDetails.category",
          totalSold: { $sum: { $ifNull: ["$items.qty", 1] } }
        }
      },

      { $sort: { totalSold: -1 } }
    ]);

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------
// 4️⃣ MOST REVIEWED BOOKS
// --------------------------------------------
router.get("/most-reviewed", async (req, res) => {
  try {
    const data = await Book.aggregate([
      {
        $addFields: { totalReviews: { $size: "$reviews" } }
      },
      { $sort: { totalReviews: -1 } },
      { $limit: 10 }
    ]);

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------
// 5️⃣ AVERAGE ORDER VALUE
// --------------------------------------------
router.get("/average-order-value", async (req, res) => {
  try {
    // const data = await Order.aggregate([
    //   {
    //     $group: {
    //       _id: null,
    //       avgOrderValue: { $avg: "$totalAmount" }
    //     }
    //   }
    // ]);
const data = await Order.aggregate([
      { $unwind: "$items" },
      {
        $group: {
          _id: "$_id",
          orderTotal: {
            $sum: { $multiply: ["$items.price", "$items.qty"] }
          }
        }
      },
      {
        $group: {
          _id: null,
          avgOrderValue: { $avg: "$orderTotal" }
        }
      }
    ]);
    res.json(data[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
