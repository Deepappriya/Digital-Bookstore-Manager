const express = require("express");
const router = express.Router();
const Book = require("../models/Book");
const auth = require("../middleware/auth");
const User = require("../models/User");   // <-- add this line
const mongoose = require("mongoose");
// 📚 Create a new book (Admin only in future, for now just auth)
router.post("/", auth, async (req, res) => {
  try {
    const book = new Book(req.body);
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 📚 Get all books (Public)
router.get("/", async (req, res) => {
  const books = await Book.find();
  res.json(books);
});
// 📌 Get unique book categories
router.get("/categories", async (req, res) => {
  try {
    const categories = await Book.distinct("category");
    res.json(categories);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch categories" });
  }
});

// 📚 Get single book
router.get("/:id", async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ msg: "Book not found" });
    res.json(book);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 📚 Update book
router.put("/:id", auth, async (req, res) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!book) return res.status(404).json({ msg: "Book not found" });
    res.json(book);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 📚 Delete book
router.delete("/:id", auth, async (req, res) => {
  try {
    await Book.findByIdAndDelete(req.params.id);
    res.json({ msg: "Book deleted" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// module.exports = router;
// ----------------- REVIEWS -----------------

// POST /api/books/:id/reviews  -> Add or update review by logged-in user
router.post("/:id/reviews", auth, async (req, res) => {
  try {
    const bookId = req.params.id;
    const { rating, comment } = req.body;
    const userId = req.user?.id;
    const user = await User.findById(userId).select("name");
    // const name = req.user?.name || "Anonymous";
const name = user?.name || "Anonymous";
    if (!userId) return res.status(401).json({ msg: "Authorization required" });
    if (!rating || rating < 1 || rating > 5) return res.status(400).json({ msg: "Rating must be 1-5" });

    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ msg: "Book not found" });

    // Check if user already reviewed
    const existing = book.reviews.find(r => r.userId && r.userId.toString() === userId.toString());
    if (existing) {
      existing.rating = rating;
      existing.comment = comment || "";
      existing.createdAt = Date.now();
    } else {
      book.reviews.push({ userId, name, rating, comment });
    }

    // Recalculate stats
    book.reviewsCount = book.reviews.length;
    const sum = book.reviews.reduce((s, r) => s + (r.rating || 0), 0);
    book.avgRating = book.reviews.length ? Number((sum / book.reviews.length).toFixed(2)) : 0;

    await book.save();
    return res.json({
      msg: "Review saved",
      avgRating: book.avgRating,
      reviewsCount: book.reviewsCount,
      reviews: book.reviews
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

// GET /api/books/:id/reviews  -> Fetch all reviews + avg rating
router.get("/:id/reviews", async (req, res) => {
  try {
    const book = await Book.findById(req.params.id).select("reviews avgRating reviewsCount");
    if (!book) return res.status(404).json({ msg: "Book not found" });
    return res.json({
      reviews: book.reviews,
      avgRating: book.avgRating,
      reviewsCount: book.reviewsCount
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

// DELETE /api/books/:bookId/reviews/:reviewId -> Delete review (admin or review owner)
router.delete("/:bookId/reviews/:reviewId", auth, async (req, res) => {
  try {
    const { bookId, reviewId } = req.params;
    const userId = req.user?.id;
    const role = req.user?.role;

    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ msg: "Book not found" });

    const review = book.reviews.id(reviewId);
    if (!review) return res.status(404).json({ msg: "Review not found" });

    // Only admin or the review owner can delete
    if (role !== "admin" && review.userId.toString() !== userId.toString()) {
      return res.status(403).json({ msg: "Not authorized to delete this review" });
    }

    review.deleteOne();

    // Recalculate stats
    book.reviewsCount = book.reviews.length;
    const sum = book.reviews.reduce((s, r) => s + (r.rating || 0), 0);
    book.avgRating = book.reviews.length ? Number((sum / book.reviews.length).toFixed(2)) : 0;

    await book.save();
    return res.json({
      msg: "Review deleted",
      avgRating: book.avgRating,
      reviewsCount: book.reviewsCount
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Server error" });
  }
});
// Recommend books that co-occur with a given bookId in orders
const { ObjectId } = require("mongodb");
const Order = require("../models/Order");
async function recommendBooks(req, res) {
  try {
    const selectedBookId = req.params.bookId;
     const selectedObjId = new mongoose.Types.ObjectId(selectedBookId);
    let objectId = null;
    try {
      objectId = new mongoose.Types.ObjectId(bookId);
    } catch (e) {}

    const recommendations = await Order.aggregate([
      { $match: { "items.id": selectedObjId } },

  // 2. Collect all user IDs who bought this book
  { $group: { _id: "$userId" } },

  // 3. Find all books purchased by those users
  {
    $lookup: {
      from: "orders",
      localField: "_id",
      foreignField: "userId",
      as: "userOrders"
    }
  },

  { $unwind: "$userOrders" },
  { $unwind: "$userOrders.items" },

  // 4. Group by book_id AND exclude the selected book
  {
    $match: {
      "userOrders.items.id": { $ne: selectedObjId }
    }
  },

  // 5. Count occurrences of other books
  {
    $group: {
      _id: "$userOrders.items.id",
      count: { $sum: 1 }
    }
  },

  // 6. Sort descending (most frequently co-bought)
  { $sort: { count: -1 } },

  // 7. Join with book collection to get details
  {
    $lookup: {
      from: "books",
      localField: "_id",
      foreignField: "_id",
      as: "bookDetails"
    }
  },

  { $unwind: "$bookDetails" },

  // 8. Final output
  {
    $project: {
      _id: 1,
      count: 1,
      title: "$bookDetails.title",
      price: "$bookDetails.price"
    }
  }
]);

    res.json(recommendations);

  } catch (err) {
    console.error("recommendBooks error:", err);
    res.status(500).json({ message: "Error generating recommendations" });
  }
}


router.get("/:bookId/recommend", recommendBooks);
// 📌 Get books by category
router.get("/category/:name", async (req, res) => {
  try {
    const category = req.params.name;

    const books = await Book.find({
      category: { $regex: new RegExp("^" + category + "$", "i") }
    });

    res.json(books);
  } catch (err) {
    res.status(500).json({ message: "Error fetching category books" });
  }
});

// router.get("/search", async (req, res) => {
//   try {
//     const q = req.query.q;

//     const books = await Book.find({
//       $or: [
//         { title: { $regex: q, $options: "i" } },
//         { author: { $regex: q, $options: "i" } },
//         { category: { $regex: q, $options: "i" } }
//       ]
//     });

//     res.json(books);
//   } catch (err) {
//     res.status(500).json({ msg: "Server error" });
//   }
// });
router.get("/books", async (req, res) => {
  const search = req.query.search;

  try {
    let books = [];

    // if search keyword provided
    if (search && search.trim() !== "") {

      // 1️⃣ First: Try Full-Text Search
      books = await Book.find({ $text: { $search: search } });

      // 2️⃣ If No Results ➜ Partial Regex Search
      if (books.length === 0) {
        books = await Book.find({
          $or: [
            { title: { $regex: search, $options: "i" } },
            { author: { $regex: search, $options: "i" } },
            { description: { $regex: search, $options: "i" } }
          ]
        });
      }

    } else {
      // No search → return all books
      books = await Book.find();
    }

    res.json(books);

  } catch (err) {
    console.error("❌ Search Error:", err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
