// backend/routes/auth.js
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Order = require("../models/Order");
const auth = require("../middleware/auth");
const router = express.Router();

// Register
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) return res.status(400).json({ msg: "Please fill all fields" });

    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ msg: "User already exists" });

    const salt = await bcrypt.genSalt(10);
    const hashed = await bcrypt.hash(password, salt);

    // const user = new User({ name, email, password: hashed, role });
    user = new User({
      name,
      email,
      password: hashed,
      role: role || "customer",
    });
    await user.save();

    return res.status(201).json({ msg: "User registered successfully" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error" });
  }
});

// Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ msg: "Please provide email and password" });

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: "Invalid credentials" });

    const payload = { id: user._id, role: user.role };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "6h" });

    return res.json({
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error" });
  }
});
router.get("/me", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    res.json(user);
  } catch (err) {
    res.status(500).json({ msg: "Server error" });
  }
});
// 🧾 Fetch My Orders
async function fetchMyOrders() {
  const token = localStorage.getItem("token");

  const res = await fetch("http://localhost:5000/api/orders/my", {
    headers: { Authorization: "Bearer " + token }
  });

  const orders = await res.json();
  const list = document.getElementById("myOrdersList");

  if (!orders.length) {
    list.innerHTML = "<p>No orders found yet!</p>";
    return;
  }

  list.innerHTML = orders.map(o => `
    <div class="order-card">
      <div class="order-header">
        <h4>Order #${o._id.slice(-5).toUpperCase()}</h4>
      </div>
      <div class="order-body">
        <p><b>Status:</b> ${o.status}</p>
        <p><b>Total:</b> ₹${o.total}</p>
        <p><b>Placed on:</b> ${new Date(o.createdAt).toLocaleString()}</p>
        <div class="items-list">
          <b>Items:</b><br>
          ${o.items.map(i => `• ${i.qty} × ${i.title} (₹${i.price})`).join("<br>")}
        </div>
      </div>
    </div>
  `).join("");
}

module.exports = router;
// module.exports = router;
