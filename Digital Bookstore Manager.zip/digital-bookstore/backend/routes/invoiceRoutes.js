// import express from "express";
// import { generateInvoicePDF } from "../utils/invoicGenerator.js";

// const router = express.Router();

// router.get("/invoice/:orderId", async (req, res) => {
//   const orderId = req.params.orderId;

//   // Example data (you will get this from DB)
//   const data = {
//     orderId,
//     customerName: "John Doe",
//     date: new Date().toLocaleDateString(),
//     itemsHtml: `
//       <tr>
//         <td>Book A</td>
//         <td>1</td>
//         <td>₹300</td>
//         <td>₹300</td>
//       </tr>
//     `,
//     total: 300
//   };

//   const pdf = await generateInvoicePDF(data);

//   res.set({
//     "Content-Type": "application/pdf",
//     "Content-Disposition": `attachment; filename=invoice_${orderId}.pdf`
//   });

//   res.send(pdf);
// });

// export default router;

const express = require("express");
const { generateInvoicePDF } = require("../utils/invoicGenerator");
const Order = require("../models/Order");
const auth = require("../middleware/auth");

const router = express.Router();

// Generate invoice PDF for a specific order
router.get("/invoice/:orderId", auth, async (req, res) => {
  try {
    const orderId = req.params.orderId;
    // const order = await Order.findById(orderId);
    const order = await Order.findById(req.params.orderId)
    .populate("userId", "name email")  // <-- POPULATE USER NAME & EMAIL
    .lean();
    // console.log("ORDER FETCHED FOR INVOICE:", order);
    if (!order) return res.status(404).json({ message: "Order not found" });

    // Build HTML rows for items
    const itemsHtml = order.items
      .map(
        (item) => `
      <tr>
        <td>${item.title}</td>
        <td>${item.qty}</td>
        <td>₹${item.price}</td>
        <td>₹${item.qty * item.price}</td>
      </tr>`
      )
      .join("");

    const data = {
      orderId,
      customerName: order.userId?.name || "Customer",
      date: new Date(order.createdAt).toLocaleDateString(),
      itemsHtml,
      total: order.total,
    };

    const pdfBuffer = await generateInvoicePDF(data);

    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename=invoice_${orderId}.pdf`,
    });

    res.send(pdfBuffer);
  } catch (error) {
    console.error("Invoice error:", error);
    res.status(500).json({ message: "Invoice generation failed" });
  }
});

module.exports = router;
