const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Order = require("../models/Order");
const Book = require("../models/Book");
router.post("/process", auth, async (req, res) => {
  try {
    const { orderId, paymentMethod } = req.body;

    if (!orderId) {
      return res.status(400).json({ message: "Order ID missing" });
    }
     const order = await Order.findById(orderId);
console.log("ORDER ITEMS:", order.items);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    for (const item of order.items) {
      console.log("Reducing stock for:", item.bookId, "Qty:", item.qty);
      await Book.findByIdAndUpdate(
        item.bookId,        // bookId stored in order
        { $inc: { stock: -item.qty } }
      );
    }
    await Order.findByIdAndUpdate(orderId, {
      paymentStatus: "Paid",
      paymentMethod: paymentMethod || "Card",
      status: "Confirmed"
    });

    res.json({ success: true, message: "Payment successful" });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Payment error" });
  }
});
router.post("/initiate", auth, async (req, res) => {
  const { items, total } = req.body;
const formattedItems = items.map(i => ({
    bookId: i.bookId,
    title: i.title,
    price: i.price,
    qty: i.quantity
  }));
// console.log("FORMATTED ITEMS:", formattedItems);

  const order = await Order.create({
    userId: req.user.id,
    items:formattedItems,
    total,
    status: "Pending"
  });

  res.json({ orderId: order._id });  // Ensure THIS exists
});

module.exports = router;
