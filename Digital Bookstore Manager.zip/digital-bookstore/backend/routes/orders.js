const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Order = require("../models/Order");
const Book = require("../models/Book");

// 🛒 Create new order
// router.post("/", auth, async (req, res) => {
//   try {
//     const { items, total } = req.body;

//     if (!items || items.length === 0) {
//       return res.status(400).json({ msg: "No items in order" });
//     }
//     for (const item of items) {
//       const book = await Book.findById(item.bookId);
//       if (!book || book.stock < item.quantity) {
//         return res.status(400).json({ msg: `${book?.title || 'Book'} out of stock` });
//       }
//     }
//     // ✅ Create new order
//     const newOrder = new Order({
//       userId: req.user.id,
//       items,
//       total,
//       status: "Placed",
//       createdAt: new Date()
//     });

//     await newOrder.save();

//     // ✅ Decrease stock for each ordered book
//     for (const item of items) {
//       await Book.findByIdAndUpdate(
//         item.bookId,
//         { $inc: { stock: -item.quantity } },  // decrement stock
//         { new: true }
//       );
//     }
// //     const book = await Book.findById(item.bookId);
// // if (!book || book.stock < item.quantity) {
// //   return res.status(400).json({ msg: `${book?.title || 'Book'} is out of stock` });
// // }
//     res.status(201).json({ msg: "Order placed successfully", order: newOrder });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ msg: "Server error" });
//   }
// });
router.post("/", auth, async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user.id })
      .populate("items.id", "title author image price") // 🧠 populate book details
      .sort({ createdAt: -1 });

    // res.json(orders)
    const { items, total } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ msg: "No items in order" });
    }

    // ✅ Validate and format items before saving
    const formattedItems = [];
    for (const item of items) {
      const bookId = item.bookId || item.id;
      const quantity = item.quantity || item.qty;

      const book = await Book.findById(bookId);
      if (!book || book.stock < quantity) {
        return res.status(400).json({ msg: `${book?.title || 'Book'} out of stock` });
      }

      console.log(bookId,quantity);
      // ✅ Decrease stock
      await Book.findByIdAndUpdate(
        bookId,
        { $inc: { stock: -quantity } },
        { new: true }
      );
      formattedItems.push({
        id: bookId,
        title: book.title,
        price: book.price,
        qty: quantity
      });

      // // ✅ Decrease stock
      // await Book.findByIdAndUpdate(
      //   bookId,
      //   { $inc: { stock: -quantity } },
      //   { new: true }
      // );
    }

    // ✅ Create new order with correct item structure
    const newOrder = new Order({
      userId: req.user.id,
      items: formattedItems,
      total,
      status: "Placed",
      createdAt: new Date()
    });

    await newOrder.save();

    return res.status(201).json({ msg: "Order placed successfully", order: newOrder });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

// 📦 Get all orders (Admin only)
router.get("/admin", auth, async (req, res) => {
  try {
    if (req.user.role !== "admin")
      return res.status(403).json({ msg: "Access denied" });
    const orders = await Order.find().populate("userId", "name email");
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📋 Get user's own orders
router.get("/my", auth, async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🔄 Update order status (Admin)
router.put("/:id/status", auth, async (req, res) => {
  try {
    if (req.user.role !== "admin")
      return res.status(403).json({ msg: "Access denied" });

    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true }
    );
    if (!order) return res.status(404).json({ msg: "Order not found" });
    res.json({ msg: "Order status updated", order });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
