exports.getTopBooks = async (req, res) => {
  try {
    res.json({
      message: 'Top books analytics working',
      data: []
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
