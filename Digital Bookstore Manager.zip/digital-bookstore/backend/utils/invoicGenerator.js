import fs from "fs";
import path from "path";
import puppeteer from "puppeteer";
import PDFDocument from "pdfkit";
import { fileURLToPath } from "url";

// FIX: define __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
export async function generateInvoicePDF(data) {
  const templatePath = path.join(__dirname, "../templates/invoiceTemplate.html");
  let html = fs.readFileSync(templatePath, "utf-8");

  // Replace placeholders
  html = html
    .replace("{{orderId}}", data.orderId)
    .replace("{{customerName}}", data.customerName)
    .replace("{{date}}", data.date)
    .replace("{{itemsHtml}}", data.itemsHtml)
    .replace("{{total}}", data.total);

  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: "networkidle0" });

  const pdf = await page.pdf({
    format: "A4",
    printBackground: true   // VERY IMPORTANT → prints CSS background colors
  });

  await browser.close();
  return pdf;
}
// module.exports = { generateInvoicePDF };
// export const generateInvoicePDF = async (order) => {

//   const invoiceDir = path.join(__dirname, "../invoices");
//   if (!fs.existsSync(invoiceDir)) {
//     fs.mkdirSync(invoiceDir);
//   }

//   const filePath = path.join(invoiceDir, `invoice_${order._id}.pdf`);

//   const doc = new PDFDocument();
//   doc.pipe(fs.createWriteStream(filePath));

//   // Your styled invoice content…
//   doc.fontSize(20).text("Invoice", { underline: true });
//   doc.fontSize(14).text(`Customer: ${order.customerName}`);
//   // ...
  
//   doc.end();
//   return filePath;
// };